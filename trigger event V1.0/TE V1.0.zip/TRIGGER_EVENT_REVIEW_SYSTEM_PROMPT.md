# ZA Bank BB Trigger Event Review 頁面 — Claude API 精確還原指令

> **版本：** `bb_trigger_event_review_v2.html`（2026-04-24）
> **用途：** 指導 Claude API 一比一精確還原 Trigger Event Review 頁面，並根據 V1.9 MD 準確實現全部功能

---

---

## 〇、UI 實現核心原則：直接複用 HTML 文件代碼（最高優先級，不可違反）

**`bb_trigger_event_review_v2.html` 是 UI 的唯一實現基礎。嚴禁重寫 UI 代碼。**

### 具體操作方式

#### 前端組件實現步驟（按此執行，不得偏離）

```
Step 1  讀取 bb_trigger_event_review_v2.html 的完整 HTML 內容
Step 2  直接提取 <style> 標籤內的全部 CSS，一字不改地放入
        src/styles/bb-trigger.css
        不得重命名任何 class，不得新增或刪除任何規則
Step 3  提取 <body> 的 DOM 結構，按 React 組件邊界拆分：
          BBTriggerLayout      → 三欄骨架（.gnav / .sidebar / .main / .rp）
          BBTriggerSidebar     → 左側導航（直接複用 .sidebar 內的 HTML）
          BBTriggerHeader      → 進度條 + Trigger Banner（#s-hdr 卡片）
          BBCaseOverview       → #s-cr 卡片
          BBRiskAssessment     → #s-risk 卡片
          BBFieldChangeReview  → #s-1 大卡片（含所有 diff-table）
          BBTUSearch           → #s-tu 卡片
          BBCustomerRisk       → #s-cra-card 卡片
          BBAttachments        → #s-doc 卡片
          BBCaseContent        → #s-cc 卡片
          BBApprovalPanel      → .rp 右側面板
Step 4  把每個組件對應的 HTML 片段直接貼入 JSX（保留所有 class 名、
        inline style、data-* 屬性，不做任何樣式上的調整）
Step 5  僅替換硬編碼的示例數據為 props/state 驅動的動態數據
Step 6  把 <script> 標籤內的 JS 函數（initDiffTracking / markSelectChanged /
        addCompRow / toggleRemarkInline / openDetailModal / openRssModal /
        scrollToAnchor 等）原封不動地移入對應組件的 useEffect 或事件處理函數
Step 7  運行 TypeScript 編譯，解決類型錯誤（不得改動 DOM 結構或 class 名）
```

#### 嚴格禁止的行為

- ❌ 禁止用 Ant Design 組件替換原型中的 `<table>` / `<select>` / `<input>` / `<div>`
- ❌ 禁止重新設計任何視覺元素（顏色、間距、圓角、字號）
- ❌ 禁止重命名任何 CSS class（`.diff-table` / `.mv-r` / `.rch` / `.sc` 等）
- ❌ 禁止刪除任何 inline style
- ❌ 禁止把靜態 HTML 替換為 Ant Design 的 Form / Table / Modal 組件
- ❌ 禁止因為「更優雅」或「更 React 化」而改變 DOM 結構

#### 允許的調整（僅限以下）

- ✅ 硬編碼的示例數據（如 "ABC Trading Limited"）替換為 `{caseData.companyEnName}`
- ✅ `onclick="..."` 替換為 React `onClick={handleXxx}`
- ✅ `display:none` 替換為 React 條件渲染 `{visible && <tr>...</tr>}`
- ✅ 新增 TypeScript 類型注釋
- ✅ 把重複出現的片段（如 34 個國家選項）抽取為常量

#### 驗收標準

完成後，在同一瀏覽器窗口並排打開：
- 左：`bb_trigger_event_review_v2.html`（靜態原型）
- 右：`http://localhost:3000/bb-cases/TEV-BB-20260418-000012`（React 實現）

逐模塊截圖對比，要求肉眼無法分辨差異。如有任何差異，調整代碼直到一致。

---

## 一、輸入文件清單（開始前必須全部讀取）

| 文件 | 路徑 | 優先級 |
|------|------|--------|
| **UI 原型（唯一視覺標準）** | `bb_trigger_event_review_v2.html` | ★★★ 最高 |
| **業務規格** | `BB_Account_Opening_Fields_20260417_V1_9.md` | ★★★ 最高 |

**優先級規則：**
- `bb_trigger_event_review_v2.html` 是 UI 的**唯一來源**，所有視覺、交互、JS 邏輯均已完整實現，直接複用即可，無需參照任何其他 HTML 文件
- `BB_Account_Opening_Fields_20260417_V1_9.md` 是業務邏輯的唯一標準，字段定義/枚舉值/校驗規則以此為準
- 兩者衝突時，業務邏輯以 MD 為準，視覺以 HTML 原型為準，代碼注釋標注差異

---

## 二、頁面整體架構（必須完全照抄）

### 2.1 三欄佈局

```
┌─────────────────────────────────────────────────────────┐
│  .gnav（sticky top:0, height:46px, z-index:300）         │
├──────────┬──────────────────────────┬───────────────────┤
│ .sidebar │ .main (#main-scroll)     │ .rp（審批面板）   │
│ 192px    │ flex:1, overflow-y:auto  │ 360px             │
│ fixed    │ padding:12px 14px        │ overflow-y:auto   │
└──────────┴──────────────────────────┴───────────────────┘
```

### 2.2 左側導航結構（class：.sidebar）

```
功能
  ⚡ Trigger Review    → #s-hdr
  📋 Case Overview     → #s-cr
  !  Risk Assessment   → #s-risk
  CR Customer Risk     → #s-cra-card
資料表單
  1  Company Info          → #s-1
  2  Contact Details       → #s-2
  3  Business Background   → #s-3
  4  Financial Indicator   → #s-4
  5  Source of Wealth      → #s-5
  6  Anticipated Txn       → #s-6
  7  FATCA / CRS           → #s-7
  8  Company Change        → #s-8
  9  Connected Parties     → #s-9
其他
  TU TU Company Search  → #s-tu
  📎 Attachments         → #s-doc
  📋 Case Content        → #s-cc
```

**scroll 行為：** 點擊導航項時，使用 `mainEl.scrollTo({top: target.offsetTop - 60, behavior:'smooth'})`，偏移 60px 防止標題被遮擋。

### 2.3 主要 Section 結構

```
#s-hdr  — Trigger Banner（進度條 + 觸發事件說明）
#s-cr   — Case Overview（公司身份 highlight + 12個info字段）
#s-risk — Risk Assessment（Initial/Final Risk + Score Breakdown + Review Indicator）
#s-1    — Field Change Review 大卡片（包含所有 Section 1-9 的 diff-table）
#s-tu   — TU Company Search（三個 Tab：Entity Details / Connected Party / Related Documents）
#s-cra-card — Customer Risk 詳細評估（19行CR表格）
#s-doc  — Bank Supplement Attachment（客戶檔案原有 + 本次觸發事件審核 兩個區塊）
#s-cc   — Case Content / Flow Chart（Tab 切換）
```

---

## 三、CSS 提取規則（開發前必須先執行）

從 `bb_trigger_event_review_v2.html` 的 `<style>` 標籤提取 **191 個 CSS classes**，建立以下樣式文件：

```bash
# 提取所有 CSS，輸出到 variables.css
python3 << 'EOF'
import re
with open('bb_trigger_event_review_v2.html') as f:
    content = f.read()
styles = re.findall(r'<style>(.*?)</style>', content, re.DOTALL)
print('\n'.join(styles))
EOF
```

**必須保留的關鍵 class 名（一個都不能改名）：**

| Class | 用途 |
|-------|------|
| `.gnav` | 全局導航欄 |
| `.sidebar` | 左側導航 |
| `.main` | 主內容滾動區 |
| `.rp` | 右側審批面板 |
| `.card` / `.card-hd` / `.card-hd-l` | 卡片結構 |
| `.diff-table` | 字段對比表格 |
| `.diff-sec-hd` | Section 分組標題（藍色） |
| `.fn` | 字段名稱（Field Name） |
| `.di` | 可編輯輸入控件（input/select/checkbox） |
| `.mod` | 已修改的控件（橙色邊框高亮） |
| `.sc` / `.sc-ch` / `.sc-ok` / `.sc-ns` | 狀態 badge（Changed/Unchanged/NS） |
| `.rch` | 已變更的 tr 行（橙色左邊框） |
| `.rns` | NS Required 的 tr 行（紫色左邊框） |
| `.unch-row` | 未變更行（「Show changed only」時隱藏） |
| `.mv-r` | 多值行 wrapper（用於動態增刪） |
| `.btn-add-row` / `.btn-del-row` | 多值行增刪按鈕 |
| `.cr-table` / `.cr-hi` / `.cr-med` | Customer Risk 表格樣式 |
| `.cr-score` / `.cs-r` / `.cs-ok` | CR 評分 badge |
| `.risk-hi` / `.risk-med` / `.risk-lo` | 風險等級標籤 |
| `.rp-btn` / `.rb-pu` / `.rb-bl` / `.rb-ok` | 右側面板按鈕 |
| `.rp-lbl` / `.rp-ta` / `.ro-select` / `.ro-input` | 右側面板字段 |
| `.doc-table` / `.doc-name` / `.doc-meta` / `.doc-upload` | 附件表格 |
| `.tag` / `.tbb` / `.tst` / `.tpd` / `.tgy` / `.tam` / `.tpu` / `.tbl` | 各類 badge 顏色 |
| `.sb-a` / `.sb-sec` / `.sbn` / `.nb` / `.na` / `.nr` / `.nt` / `.ng` | 導航項樣式 |
| `.ov-id` / `.ov-cell` / `.ov-l` / `.ov-v` | Case Overview 身份高亮行 |
| `.ci-grid` / `.ci-l` / `.ci-v` | Case Overview 信息網格 |

---

## 四、Field Change Review（核心模塊）精確實現規範

### 4.1 表格結構

```html
<table class="diff-table">
  <thead>
    <tr><th>Field</th><th>Original Value</th><th>Modified Value</th><th>Status</th></tr>
  </thead>
  <tbody>
    <!-- 每行字段 -->
    <tr class="rch | rns | unch-row">
      <td><div class="fn">字段名<span class="req">*</span><span class="ns">NS</span></div></td>
      <td><span class="val-old | val-unch">原始值</span></td>
      <td><!-- 可編輯控件 --></td>
      <td><span class="sc sc-ch | sc-ok | sc-ns">Changed | Unchanged | New · NS</span></td>
    </tr>
  </tbody>
</table>
```

### 4.2 Section 分組

每個 Section 用 `<div class="diff-sec-hd" id="s-N">` 分隔，右側顯示變更統計 badge：

```html
<div class="diff-sec-hd" id="s-1">
  <span>1 · COMPANY INFORMATION</span>
  <span style="display:flex;gap:5px">
    <span class="tag tam" style="font-size:10px">3 changed</span>
    <span class="tag tpu" style="font-size:10px">2 NS</span>
  </span>
</div>
```

### 4.3 各類控件精確對應（按 V1.9 MD 字段定義）

**① 簡單下拉（ENUM 字段）**
```html
<select class="di" style="height:28px">
  <option value="01" selected>01 - 枚舉值描述</option>
</select>
```

**② 日期選擇器（DATE 字段）**
```html
<input class="di" type="date" value="2020-01-01" style="height:28px">
```
> 注意：composite row 內的日期字段用 `type="text" placeholder="YYYY-MM-DD"`（避免 flex 佈局下 date picker 被壓縮）

**③ 多值 checkbox 組（枚舉多選字段）**
```html
<div style="display:flex;flex-direction:column;gap:4px;padding:2px 0">
  <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;white-space:nowrap">
    <input type="checkbox" value="BI" checked> BI - Business Income
  </label>
  <!-- 更多選項... -->
</div>
```

**④ 動態加行複合組（多值複合字段）**
```html
<div style="width:100%">
  <div class="mv-r" style="display:flex;gap:5px;align-items:flex-end;margin-bottom:4px">
    <!-- 各子字段（flex:1 或 flex:N） -->
    <div style="display:flex;flex-direction:column;gap:2px;flex:1">
      <div style="font-size:10px;color:#999">子字段標籤</div>
      <input class="di" type="text" style="height:28px;width:100%">
    </div>
    <button class="btn-del-row" onclick="this.closest('.mv-r').remove()">×</button>
  </div>
  <button class="btn-add-row" onclick="addCompRow(this)">+ Add</button>
</div>
```

**⑤ 國家多值選擇**
```html
<div style="display:flex;flex-direction:column;gap:6px;width:100%">
  <div class="mv-r" style="display:flex;gap:5px;align-items:center">
    <select class="di" style="height:28px;flex:1">
      <!-- 34個國家枚舉選項 -->
    </select>
    <button class="btn-del-row" onclick="this.closest('.mv-r').remove()">×</button>
  </div>
  <button class="btn-add-row" onclick="addNatRow(this)">+ Add</button>
</div>
```

**⑥ 地址分字段（Room/Floor/Building/Street/District/Country）**
```html
<div style="display:flex;flex-direction:column;gap:5px;width:100%">
  <div style="display:flex;gap:5px">
    <div style="flex:1;display:flex;flex-direction:column;gap:2px">
      <div style="font-size:10px;color:#999">Room / Flat</div>
      <input class="di" type="text" style="height:28px;width:100%">
    </div>
    <div style="flex:1;display:flex;flex-direction:column;gap:2px">
      <div style="font-size:10px;color:#999">Floor</div>
      <input class="di" type="text" style="height:28px;width:100%">
    </div>
  </div>
  <!-- Building / Street / District+Country -->
  <div style="font-size:10px;color:#888;padding:3px 6px;background:#f9f9f9;border-radius:3px">
    📍 地址預覽行（自動拼接）
  </div>
</div>
```

**⑦ 百分比欄（Share %）**
```html
<div style="display:flex;flex-direction:column;gap:2px;flex:15px">
  <div style="font-size:10px;color:#999">Share %</div>
  <div style="display:flex;align-items:center;gap:4px">
    <input class="di" type="text" value="20" style="height:28px;width:100%">
    <span style="font-size:13px;color:#595959;flex-shrink:0;font-weight:500">%</span>
  </div>
</div>
```

### 4.4 各 Section 字段完整清單

> 以下為各 Section 包含的字段及對應控件類型，必須按此實現，不得遺漏：

**Section 1 — Company Information（26 字段）**
Company Type（下拉）/ ID Type（下拉）/ ID Number（文字）/ Other IDs（複合多值：Type+Number）/ Company EN Name（文字，Changed示例）/ Company CN Name（文字）/ Trading Name EN（複合多值：Name）/ Trading Name CN（複合多值：Name）/ Company Establish Date（date picker）/ Country of Registration（完整國家下拉）/ Listing Company（下拉 Y/N）/ High Tax Evasion Risk（下拉 Y/N）/ Name(s) of Stock Exchange（文字）/ Bearer Shares Issued（下拉 Y/N）/ Intermediate Owners Issue Bearer Shares（下拉 Y/N）/ Channel（下拉 W/A/B/I/O）/ Usage of Products（下拉 01/03 兩個選項）/ On PEC（下拉 Y/N）/ Number of Layers of Ownership Structure（下拉 1-10）/ Internal Client Type（下拉 PUBLIC SECTOR/OTHER）/ Account Officer（下拉 8個RM選項）/ Business Nature（下拉 7個選項）/ Country of Risk（國家下拉）/ Country of Origin（國家下拉）/ Classify（下拉 S/C/Z/N）/ Board Resolution（下拉 Y/N）/ Complex Structure（Radio Yes/No）

**Section 2 — Contact Details（17 字段）**
地址三個（Registered/Operation/Mailing Address，各6子字段）/ Declaration（下拉 1-4）/ Reason（文字）/ Contact Person First Name / Last Name / Contact Tel Area Code（下拉 +852/+86等）+ Telephone Number / Email Address / Job Title（下拉 01-09）/ Other Job Title / Office Telephone（區號下拉+號碼）/ Company Website / Group CIF Number / Group CIF Name

**Section 3 — Business Background（17 字段）**
Office Location（國家下拉）/ Principal Place（國家下拉）/ Countries of Foreign Branch（國家多值）/ Country of Key Counterparties（複合多值：Country）/ Industry Category（21選項NACE下拉，聯動）/ Key Products（聯動下拉）/ Industry 2 / Key Products 2 / Regulatory Body/Ref/Country / Employees（複合多值：Country+Number）/ WEB3（Y/N）/ Is Greater China（Y/N）/ Financial Background / Is Holding Company / Referral Party

**Section 4 — Financial Indicator（16 字段）**
Turnover/Net Profit/Asset Size / Others / Supplier（複合多值：Country+Company+Share%）/ Buyer（複合多值：Country+Company+Share%）/ Assets Held（複合多值：Country+Share%）/ Jurisdiction（複合多值：Country+Purpose）/ SEQ Q1-Q4（下拉 Y/N，含拒絕規則備注）/ Purpose for Account Opening（checkbox 7選項）/ Group 1.5B / Non-SME

**Section 5 — Source of Wealth/Fund（8 字段）**
Initial SOF / Ongoing SOF / Initial SOW / Ongoing SOW（各為 checkbox 5選項：BI/IF/IP/SA/OT）

**Section 6 — Anticipated Transaction（18 字段）**
CB Type / CB Flag / Countries To（複合多值）/ Countries From（複合多值）/ Monthly No. Inward/Outward / Monthly Amount Inward（複合多值：Currency+Amount）/ Monthly Outward Amount（複合多值，HIGH RISK備注）/ CB Purpose（checkbox 5選項）/ Regular Domestic Flag / Regular Monthly No. Inward/Outward / Regular Monthly Amount Inward/Outward（各複合多值）/ Purpose Regular（checkbox 5選項）/ Hold Balances / Amount & Rationale

**Section 7 — FATCA/CRS（15 字段）**
FATCA Documentation（下拉 9選項）/ Classification（下拉 01-39）/ Non-consenting subtype / GIIN Code（4段分離輸入，maxlength 6/5/2/3）/ GIIN Status / Other self-cert / Disregarded entity / Sign Date FATCA（date）/ FATCA DD Status / FATCA Pre-existing / CRS Entity Classification / Sign Date CRS / Tax Residency+TIN+Reason for No TIN（複合多值：Country+TIN+Reason下拉A/B/C）/ CRS Self-cert Valid / CRS Pre-existing

**Section 8 — Company Change（5 字段）**
Material change flag（Y/N Radio）/ Company Name Change（複合多值：Old Name+Effective From+To）/ Industry Change（2×2 grid：Industry Category+Key Products+Reason+Start Date）/ Ownership Structure Change（Reason+Start Date）/ Beneficial Owners Change（Reason+Start Date）

**Section 9 — Company Secretary（3 字段）**
Secretary ID Type / ID Number（合併一行：Type下拉+Number文字）/ Secretary EN Name / Secretary CN Name / Secretary Address

**Section 9 (extra) — Connected Parties**
- **Individual（每人）：** ID Type/Number（合併行）/ First Name / Last Name / Chinese Name / Capacity（checkbox 12選項）/ Controlling Person Type / Ownership % / Job Title / Permanent HKID / ID Issue Date / Gender / Date of Birth / Place of Birth / Nationality（動態加行下拉）/ Email / Telephone（區號+號碼）/ Residential Address（6子字段）/ Beneficial Owner SOW（checkbox 5選項）/ Country of Initial/Ongoing Wealth Source（動態加行下拉）/ Related Client On PEP（checkbox 4選項）/ FATCA US Tax ID / FATCA Substantial US Owner / CRS Entity Controlling Flag / CRS Tax Residency+TIN（複合多值）
- **Entity（每個）：** ID Type/Number（合併行）/ Registered Full Name EN/CN / Entity Type / Capacity（checkbox 7選項）/ Ownership % / Listing on Stock Exchange

---

## 五、變更追蹤 JS 邏輯（精確實現）

### 5.1 初始化（DOMContentLoaded）

```javascript
function initDiffTracking(){
  // 記錄所有 .diff-table 內 select.di 的初始值
  document.querySelectorAll('.diff-table select.di').forEach(sel => {
    sel.dataset.orig = sel.value;
  });
  // 記錄所有 input.di 的初始值
  document.querySelectorAll('.diff-table input.di').forEach(inp => {
    inp.dataset.orig = inp.value;
  });
  // 記錄所有 checkbox 組的初始選中狀態
  document.querySelectorAll('.diff-table td > div').forEach(grp => {
    const cbs = grp.querySelectorAll('input[type=checkbox]');
    if(cbs.length < 2) return;
    const orig = [];
    cbs.forEach(cb => { if(cb.checked) orig.push(cb.value); });
    grp.dataset.origChecked = orig.sort().join(',');
  });

  // 事件委託（捕捉靜態行和動態新增行）
  document.querySelectorAll('.diff-table').forEach(tbl => {
    tbl.addEventListener('change', e => {
      if(e.target.tagName === 'SELECT' && e.target.classList.contains('di')) {
        markSelectChanged(e.target);
        return;
      }
      if(e.target.type === 'checkbox') {
        handleCheckboxChange(e.target);
      }
    });
    tbl.addEventListener('input', e => {
      if(!e.target.classList.contains('di') || e.target.tagName !== 'INPUT') return;
      if(e.target.dataset.orig === undefined) e.target.dataset.orig = e.target.defaultValue || '';
      const changed = e.target.value !== e.target.dataset.orig;
      e.target.style.color = changed ? '#cf1322' : '';
      e.target.style.fontWeight = changed ? '600' : '';
      e.target.style.borderColor = changed ? '#ffa39e' : '';
      updateRowStatus(e.target, changed);
    });
  });
}
```

### 5.2 Select 變更高亮

```javascript
function markSelectChanged(sel){
  // 使用 initDiffTracking 已記錄的 orig，不重新賦值
  const orig = sel.dataset.orig !== undefined ? sel.dataset.orig : sel.value;
  const changed = sel.value !== orig;
  sel.style.color = changed ? '#cf1322' : '';
  sel.style.fontWeight = changed ? '600' : '';
  sel.style.borderColor = changed ? '#ffa39e' : '';
  updateRowStatus(sel, changed);  // 不做 inComposite 過濾
}
```

### 5.3 Checkbox 組變更

```javascript
function handleCheckboxChange(cb){
  const grp = cb.closest('td > div');
  if(!grp) return;
  const allCbs = grp.querySelectorAll('input[type=checkbox]');
  if(!grp.dataset.origChecked) {
    // 首次變更時快照（不含本次操作）
    const orig = [];
    allCbs.forEach(c => {
      const wasChecked = c === cb ? !cb.checked : cb.checked;
      if(wasChecked) orig.push(c.value);
    });
    grp.dataset.origChecked = orig.sort().join(',');
  }
  const current = [];
  allCbs.forEach(c => { if(c.checked) current.push(c.value); });
  const origSet = grp.dataset.origChecked;
  const changed = current.sort().join(',') !== origSet;
  // 高亮各個 label
  allCbs.forEach(c => {
    const lbl = c.closest('label');
    if(!lbl) return;
    const inOrig = origSet.split(',').includes(c.value);
    lbl.style.color = (inOrig !== c.checked) ? '#cf1322' : '';
    lbl.style.fontWeight = (inOrig !== c.checked) ? '600' : '';
  });
  updateRowStatus(cb, changed);
}
```

### 5.4 行狀態更新

```javascript
function updateRowStatus(el, changed){
  const row = el.closest('tr');
  if(!row) return;
  const sc = row.querySelector('.sc');
  if(!sc) return;
  if(sc.classList.contains('sc-ns')) return;  // NS 行狀態固定
  if(changed){
    row.classList.remove('unch-row'); row.classList.add('rch');
    sc.className = 'sc sc-ch'; sc.textContent = 'Changed';
    row.style.display = '';
  } else {
    // 確認整行所有控件都回到原值才還原
    const anyChanged = [...row.querySelectorAll('.di')].some(ctrl => {
      if(ctrl.tagName === 'SELECT') return ctrl.value !== (ctrl.dataset.orig || ctrl.value);
      if(ctrl.tagName === 'INPUT') return ctrl.value !== (ctrl.dataset.orig || ctrl.defaultValue || '');
      return false;
    });
    if(!anyChanged){
      row.classList.remove('rch'); row.classList.add('unch-row');
      sc.className = 'sc sc-ok'; sc.textContent = 'Unchanged';
      const tog = document.getElementById('tog-changed');
      if(tog && !tog.classList.contains('off')) row.style.display = 'none';
    }
  }
}
```

### 5.5 「Show changed only」Toggle

```javascript
function toggleChangedOnly(btn){
  btn.classList.toggle('off');
  const showAll = btn.classList.contains('off');
  document.querySelectorAll('.unch-row').forEach(r => {
    r.style.display = showAll ? '' : 'none';
  });
}
```

---

## 六、Customer Risk 詳細評估（CR 表格）精確實現

### 6.1 表格列定義

```
評估維度 | Result | Detail | Initial Score | Assessment Score | Action
```

### 6.2 19 行完整清單及 Action 控件

| 行 | 評估維度 | Action 控件 |
|----|---------|------------|
| 1 | Main nature of business/industry | — |
| 2 | Date of incorporation | — |
| 3 | Entity type/Ownership structure | — |
| 4 | Bearer Shares Issued | — |
| 5 | Complex Structure | Radio（Yes/No） |
| 6 | Country of incorporation | — |
| 7 | High Tax Evasion Risk | — |
| 8 | Countries of operation | — |
| 9 | Usage of high risk products | — |
| 10 | Tax Risk | — |
| 11 | Onboarding channel | — |
| 12 | High Risk Remarks (LYOD) | `Remarks ▾`（展開 inline panel）+ `Detail`（彈窗） |
| 13 | HI Company Secretary Address | Radio（True Hit / False Hit） |
| 14 | Sanctions Exposure (LYOD) | `Detail`（彈窗） |
| 15 | PEP/Individual/SOG/Entity (LYOD) | `Detail`（彈窗） |
| 16 | Special Interest Subject (LYOD) | `Detail`（彈窗） |
| 17 | Factiva (Internal List) | `Detail`（彈窗） |
| 18 | Special List | — |
| 19 | AML Black List | `Detail`（彈窗） |

### 6.3 High Risk Remarks inline panel

```html
<!-- 在 HRR 行之後插入，初始 display:none -->
<tr id="hrr-inline-panel" style="display:none">
  <td colspan="6" style="padding:0">
    <div style="background:#fafaf8;padding:12px 16px;border-top:1px solid #e0dfd8">
      <div style="font-size:12px;font-weight:600">High Risk Remarks</div>
      <!-- 4個選項：AML Reference(disabled) / AML Grey List(disabled) / Closely Monitoring / Others -->
      <!-- Others 選中後展開 textarea（maxlength 60） -->
    </div>
  </td>
</tr>
```

### 6.4 Detail 彈窗（6 種命中類型）

彈窗 id：`#cr-detail-modal-wrap`，結構：
- 標題欄 + ✕ 關閉
- 滾動表格（22列：NO / Original Name / Name / Address / Origin / ID / Type / Additional Info / DOB / Place of Birth / Places of Birth / Hyperlinks / Nationality / Request Date / ID Type / ID No. / EN Name / CN Name / DoB / Case Reference / Result / Action）
- Result 列：5選1 Radio（Non Material Hit / True Hit + HK PEP / True Hit + Non HK PEP / True Hit + Intl Org PEP / False Hit）
- Action 列：意見文字框（4000字）+ Save 按鈕

---

## 七、右側審批面板精確實現

### 7.1 結構

```
Stats（Changed 數 / NS 數 / SLA）
Check Status（Name Screening: NS / Risk Scoring: RS）

1. 審批結果
   ○ Recommend Approval  ○ Recommend Reject  ○ Return  ○ RFI

2. Select RFI Category（RFI 時顯示，4格 2×2）
   [上傳証明材料] [補充填寫信息]
   [負責人重認証]  [客戶聯系確認]

3. Review Overview
   Transaction Limit（下拉 01-04）
   Full Review Flag（下拉 Y/N）
   Full Review Comment（文字）
   Trigger Event Reason*（下拉 01-05）
   Trigger Event Review Reason（下拉 01-13）
   Trigger Event Comment（文字）

4. 審批意見（textarea maxlength 20000 + 展開編輯 modal）

5. 附件（可選）

按鈕組（2×2）：
[💾 Save Draft]  [⚡ Risk Scoring]
[↩ Rerun Name]   [⚡ Generate RSS]

提交按鈕（全寬，顏色隨審批結果變化）：
  Recommend Approval → 綠色 #1d9e75
  Recommend Reject   → 紅色 #a32d2d
  Return             → 橙色 #854f0b
  RFI                → 藍色 #185fa5
```

### 7.2 審批意見展開 Modal

```javascript
function openCommentModal(){
  document.getElementById('modal-comment-ta').value =
    document.getElementById('rp-comment').value;
  document.getElementById('comment-modal').style.display = 'flex';
}
function saveCommentModal(){
  document.getElementById('rp-comment').value =
    document.getElementById('modal-comment-ta').value;
  closeCommentModal();
}
```

Modal 樣式：`860px wide, 90vh max-height, textarea min-height 420px`

---

## 八、各彈窗精確規範

### 8.1 Name Screening 結果彈窗（`#modal-ns`）

模擬 NS 掃描完成，顯示命中記錄表格。

### 8.2 Risk Scoring 結果彈窗（`#modal-rs`）

顯示風險評分 94.75 HIGH RISK，Score Breakdown 列表。

### 8.3 Submit 確認彈窗（`#modal-submit`）

確認提交審批，選擇審批結論對應的確認文案。

### 8.4 Generate RSS 彈窗（`#rss-modal-wrap`）

表格列：Submission Time / Generated Time / RSS Document / Action / Assessment / Remarks
底部按鈕：`⚡ Generate RSS`（生成後 1.5s loading，插入一行示例數據）/ `↺ Refresh` / `Cancel`

### 8.5 Detail 彈窗（`#cr-detail-modal-wrap`）

見第六節 6.4。

### 8.6 審批意見展開 Modal（`#comment-modal`）

見第七節 7.2。

---

## 九、Bank Supplement Attachment 雙區塊結構

```html
<!-- 客戶檔案原有（綠色標籤） -->
<div style="padding:8px 14px;...">
  <span style="color:#389e0d;background:#f6ffed;border:1px solid #b7eb8f;...">客戶檔案原有</span>
  <span>客戶 CIF 中已存在的文件（歷史上傳）</span>
</div>
<table class="doc-table">
  <!-- 6個既有文件：BR / CI / NAR1 / M&A / Individual Background / Risk Assessment -->
  <!-- 只有 Download / Preview，無 Delete -->
</table>

<!-- 本次觸發事件審核（藍色標籤） -->
<div style="padding:8px 14px;margin-top:8px;border-top:1px solid #f0f0f0;...">
  <span style="color:#0958d9;background:#e6f4ff;border:1px solid #91caff;...">本次觸發事件審核</span>
  <span>本次審核流程中上傳的附件</span>
</div>
<table class="doc-table">
  <!-- 已上傳：BR Updated / Change Notice / ID Document / Board Resolution -->
  <!-- 待上傳：NAR1 Updated / Proof of Address / Other -->
  <!-- 已上傳行：有 Delete / Download / Preview -->
  <!-- 待上傳行：class="doc-upload-row"，只有 Upload 按鈕 -->
</table>
```

---

## 十、Review Indicator 告警跳轉

```javascript
function scrollToAnchor(id){
  const el = document.getElementById(id);
  if(!el) return;
  const container = document.getElementById('main-scroll');
  const card = el.closest('.card') || el;
  const target = card !== el ? card : el;
  if(container){
    const containerTop = container.getBoundingClientRect().top;
    const targetTop = target.getBoundingClientRect().top;
    container.scrollBy({top: targetTop - containerTop - 60, behavior:'smooth'});
  }
  el.style.outline = '2px solid #fa8c16';
  el.style.outlineOffset = '3px';
  setTimeout(() => { el.style.outline = ''; el.style.outlineOffset = ''; }, 1800);
}
```

告警項對應錨點：
- ⚠ Total supplier(s) countries % < 50% → `scrollToAnchor('row-supplier')`（需在 Supplier 行加 `id="row-supplier"`）
- ⚠ Total buyer(s) countries % < 50% → `scrollToAnchor('row-buyer')`
- ● Hit CRA List → `scrollToAnchor('s-cra-card')`

---

## 十一、Common Customer Alignment Information 表格列順序

所有三個 CCAI 表格（Individual 1 / Individual 2 / Entity 1）的列順序一致：

```
Action | English Name | Chinese Name | Related Company CN Name | Relation Code |
Gender | Date of Birth | Place of Birth | Nationality |
PEP Classification | PEP Link | Tax Info | Industry 1 | Industry 2 |
Residence Address | Shareholding % | Latest Risk Rating | Update Time
```

Entity 1 無 Gender/DOB/Place/Nationality，對應列填 `N/A` 或 `—`。

---

## 十二、實現執行順序

```
Phase 0 — CSS 提取（必須最先完成）
  0.1 讀取 bb_trigger_event_review_v2.html 的全部 <style>，提取 191 個 CSS classes
  0.2 建立 src/styles/bb-trigger.module.css（class 名原樣保留，不重命名）
  0.3 建立 src/styles/variables.css（色值統一定義為 CSS 自定義屬性）
  → 驗收：所有 CSS class 名與 HTML 原型一一對應

Phase 1 — 類型定義
  1.1 TriggerEventCase 接口類型（含所有 Section 1-9 + Connected Parties）
  1.2 FieldChange 類型（field / originalValue / modifiedValue / status）
  1.3 CRAssessment 類型（19行 CR 表格）
  → 驗收：TypeScript 編譯無錯誤

Phase 2 — 靜態 UI 精確還原
  2.1 三欄佈局 + 導航欄（完全照抄 HTML 原型的 DOM 結構）
  2.2 Trigger Banner（進度條 7節點 + 觸發事件 chips）
  2.3 Case Overview 卡片（12個info字段）
  2.4 Risk Assessment 卡片（Score Breakdown 展開面板 + Review Indicator 可點擊告警）
  2.5 Field Change Review 大卡片（Section 1-9 全部字段，含所有控件類型）
  2.6 TU Company Search（3個 Tab）
  2.7 Customer Risk 表格（19行，含所有 Action 交互）
  2.8 Bank Supplement Attachment（雙區塊）
  2.9 Case Content / Flow Chart Tab
  2.10 右側審批面板（全部字段 + 按鈕組 + 提交按鈕顏色聯動）
  → 視覺驗收：與 bb_trigger_event_review_v2.html 逐像素對比

Phase 3 — 交互邏輯
  3.1 initDiffTracking()（變更追蹤初始化）
  3.2 markSelectChanged() / handleCheckboxChange() / updateRowStatus()
  3.3 「Show changed only」Toggle（過濾 unch-row）
  3.4 addCompRow() / addNatRow()（動態加行）
  3.5 toggleRemarkInline()（HRR Remarks 展開）
  3.6 openDetailModal()（6種 Detail 彈窗）
  3.7 openCommentModal() / saveCommentModal()（審批意見展開）
  3.8 openRssModal() / generateRss()（Generate RSS）
  3.9 scrollToAnchor()（Review Indicator 告警跳轉）
  3.10 導航欄 scroll-spy（點擊定位 + 滾動高亮）
  3.11 提交按鈕顏色聯動（審批結果選擇 → 按鈕顏色）
  → 交互測試：所有按鈕/彈窗/動態行均可正常觸發

Phase 4 — API 接入
  4.1 GET /api/bb-cases/:caseId（獲取完整 case 數據，含所有字段原始值）
  4.2 PUT /api/bb-cases/:caseId/fields（保存字段修改）
  4.3 POST /api/bb-cases/:caseId/risk-scoring（重跑 Risk Scoring）
  4.4 POST /api/bb-cases/:caseId/action（提交審批操作）
  4.5 POST /api/bb-cases/:caseId/rss（生成 RSS）
  → 接口測試：mock 數據正確渲染到頁面

Phase 5 — 第一輪測試（功能測試）
  必須自動執行所有以下測試項，失敗則自主修復後重測，禁止跳過任何項目：

  5.1 UI 還原驗收
      □ 並排打開原型 HTML 和 React 實現，逐模塊截圖，確認無肉眼可見差異
      □ 三欄佈局比例（192px / flex:1 / 360px）
      □ 所有 CSS class 存在且樣式正確（#185fa5 藍色 / #cf1322 紅色 / #d46b08 橙色等）
      □ Changed 行橙色左邊框 / NS 行紫色左邊框
      □ 所有多值字段 + Add / × 按鈕可正常增刪行

  5.2 字段交互測試
      □ 修改任意 select → Status 自動變 Changed，字體變紅
      □ 修改任意 input → Status 自動變 Changed，字體變紅
      □ 修改 checkbox 組 → 對應 label 變紅，行 Status 變 Changed
      □ 恢復所有控件到原值 → Status 自動還原 Unchanged
      □ composite row 內的 select（如 Reason for No TIN）變更 → 行 Status 正確更新
      □ 「Show changed only」開啟 → Unchanged 行全部隱藏，Changed 行保留
      □ 「Show changed only」關閉 → 所有行重新顯示

  5.3 多值控件測試
      □ 點擊 + Add → 新增空行，控件可正常輸入
      □ 點擊 × → 刪除對應行
      □ 地址字段6個子欄位均可輸入，預覽行自動更新
      □ GIIN Code 4段輸入各自有 maxlength，自動 uppercase
      □ 國家下拉含完整 34 個選項

  5.4 彈窗測試
      □ HRR Remarks 按鈕 → inline panel 展開/收起
      □ Others checkbox → textarea 展開/收起
      □ 各 Detail 彈窗（sanctions/pep/sis/factiva/aml/hrr）→ 正確開啟，Result Radio 可選，Save 響應
      □ Generate RSS 彈窗 → 生成後插入示例行，Download 按鈕存在
      □ 審批意見展開 Modal → 內容雙向同步（原 textarea ↔ modal textarea）
      □ Submit 確認彈窗 → 提交後 toast 通知顯示

  5.5 導航跳轉測試
      □ 點擊每個導航項 → 頁面滾動到對應 Section，標題完整可見（不被遮擋）
      □ Review Indicator 三個告警 → 分別點擊跳轉到 Supplier / Buyer / CR 表格，橙色 outline 閃爍

Phase 6 — 第二輪測試（審批流程完整測試）
  模擬完整的 RM Maker → RM Checker → AML Checker 審批流程：

  6.1 RM Maker 操作測試
      □ 選擇「Recommend Approval」→ 提交按鈕變綠色，文字變「提交 — Recommend Approval」
      □ 選擇「Recommend Reject」→ 提交按鈕變紅色
      □ 選擇「Return」→ 提交按鈕變橙色
      □ 選擇「RFI」→ 提交按鈕變藍色，顯示 RFI Category 選擇區
      □ 選擇 RFI Category（上傳证明材料）→ 顯示對應 Template
      □ Trigger Event Reason 必填校驗 → 未選時提交報錯
      □ 審批意見填寫 → 字符計數正確（最多 20000 字）
      □ 「⤢ 展開編輯」→ Modal 打開，輸入後「確認」同步回主 textarea
      □ 附件上傳（模擬）→ 已上傳文件顯示在表格中

  6.2 Risk Scoring 流程測試
      □ 點擊「⚡ Risk Scoring」→ 按鈕 loading 狀態 1.5s → 彈出結果彈窗
      □ 結果彈窗顯示 94.75 HIGH RISK + Score Breakdown
      □ 確認後 Customer Risk 表格數據更新

  6.3 Name Screening 流程測試
      □ 點擊「↩ Rerun Name」→ 按鈕 loading 狀態 → 彈出 NS 結果彈窗
      □ NS 彈窗顯示命中記錄
      □ Pending NS 指示器更新

  6.4 Generate RSS 完整流程測試
      □ 點擊「⚡ Generate RSS」→ 彈窗開啟，顯示「暫無數據」
      □ 點擊彈窗內「⚡ Generate RSS」→ 生成中 1.5s → 插入記錄行
      □ 記錄行有 Download 按鈕、Assessment 下拉、Remarks 輸入
      □ toast 顯示「RSS 已生成」

  6.5 提交審批完整流程測試
      □ 填寫 Trigger Event Reason（必填）
      □ 填寫審批意見
      □ 選擇「Recommend Approval」
      □ 點擊提交按鈕 → 確認彈窗顯示
      □ 確認 → toast 通知「提交成功」

  → 所有測試項通過後輸出測試報告

Phase 7 — 最終測試報告輸出
  輸出格式如下：

  ```
  ═══════════════════════════════════════════════
  Trigger Event Review 頁面 — 最終測試報告
  測試時間：{datetime}
  ═══════════════════════════════════════════════

  【第一輪：功能測試】
  UI 還原驗收：   通過 N 項 / 失敗 0 項
  字段交互測試：  通過 N 項 / 失敗 0 項
  多值控件測試：  通過 N 項 / 失敗 0 項
  彈窗測試：      通過 N 項 / 失敗 0 項
  導航跳轉測試：  通過 N 項 / 失敗 0 項
  第一輪合計：    ✅ 全部通過 / ❌ 失敗 N 項（已修復）

  【第二輪：審批流程測試】
  RM Maker 操作：   通過 N 項 / 失敗 0 項
  Risk Scoring：    通過 N 項 / 失敗 0 項
  Name Screening：  通過 N 項 / 失敗 0 項
  Generate RSS：    通過 N 項 / 失敗 0 項
  提交審批：        通過 N 項 / 失敗 0 項
  第二輪合計：      ✅ 全部通過 / ❌ 失敗 N 項（已修復）

  【已知限制 / 待人工確認項】
  - {限制描述}（原因：{說明}）

  【業務假設記錄】
  - {文件:行號} 假設：{描述}

  【新增 / 修改文件清單】
  src/pages/bbCases/TriggerEventReview.tsx  （主頁面）
  src/components/bb/BBFieldChangeReview.tsx  （字段對比表格）
  ...
  ═══════════════════════════════════════════════
  ```
```

---

## 十三、自主問題解決策略（禁止停下來詢問）

**核心原則：遇到任何問題，自己解決，繼續執行，不需要停下來等待確認。**

### 13.1 技術問題自主解決表

| 問題類型 | 自主解決方式 | 禁止行為 |
|---------|------------|---------|
| CSS class 不存在 | 從 `bb_trigger_event_review_v2.html` 的 `<style>` 直接複製規則 | 自行設計 |
| 字段枚舉值不確定 | 以 V1.9 MD 為準；MD 無則參照 bb_page2_data_entry.html；仍不確定則選最保守的解釋，代碼注釋標注 | 停下來問 |
| TypeScript 類型錯誤 | 補充類型定義，使用 `as` 斷言並附注釋 `// TODO: 精確化類型` | 停下來問 |
| 動態行事件失效 | 改為事件委託（event delegation）掛載到 table 容器 | 停下來問 |
| 接口不存在 / 後端未完成 | 創建 mock 實現並標注 `// TODO: 接入真實 API`，前端繼續開發 | 停下來問 |
| 依賴缺失 | `npm install <package>` 或尋找等價替代包，優先用已有依賴 | 停下來問 |
| 測試失敗（邏輯錯誤） | 閱讀報錯 → 定位問題 → 修復代碼 → 重測，循環直到通過 | 報告失敗停下來 |
| 測試失敗（環境問題） | 調整測試配置或 mock 環境依賴 | 停下來問 |
| 業務規則歧義 | 選最保守（最嚴格）的解釋，代碼注釋標注假設，繼續執行 | 停下來問 |
| 文件路徑找不到 | 搜索項目確認正確路徑 | 停下來問 |
| 編譯報錯 | 閱讀報錯 → 修復 → 重新編譯，循環直到零錯誤 | 停下來問 |
| DOM 結構衝突 | 優先保持原型 HTML 結構，調整 React 邏輯適應 | 改 DOM 結構 |

### 13.2 自主決策規則

```
如果遇到兩種實現方案的選擇：
  → 選擇更接近 HTML 原型結構的方案
  → 如果原型中已有示例代碼，直接複用

如果遇到規格文件之間的衝突：
  → 業務邏輯：以 V1.9 MD 為準
  → 視覺/交互：以 bb_trigger_event_review_v2.html 為準
  → 在代碼注釋中記錄差異：// NOTE: 與 MD 規格有差異，以 HTML 原型為準

如果某功能在原型中已實現但 MD 未提及：
  → 按原型實現，代碼注釋標注：// 原型已有，MD 未記錄

如果某功能 MD 有規格但原型未實現：
  → 按 MD 規格新增，代碼注釋標注：// MD V1.9 規格，原型未包含
```

---

## 十四、視覺驗收 Checklist

完成每個 Phase 後逐項驗收，全部通過才可進入下一 Phase：

- [ ] 三欄佈局比例正確（sidebar 192px / main flex:1 / rp 360px）
- [ ] 導航欄所有項目與內容 id 一一對應，點擊可精確跳轉
- [ ] Case Overview 公司身份 highlight 行有藍色左邊框
- [ ] Risk Assessment 卡片三列等寬，Score Breakdown 可展開/收起
- [ ] Review Indicator 告警項可點擊跳轉，到達後橙色 outline 閃爍 1.8s
- [ ] Field Change Review：Changed 行橙色左邊框，NS 行紫色左邊框
- [ ] 修改任意 select/input/checkbox 後 Status 自動變 Changed（包括 composite row 內控件）
- [ ] 恢復原值後 Status 自動還原 Unchanged
- [ ] 「Show changed only」開啟後 Unchanged 行自動隱藏
- [ ] 所有多值字段的 `+ Add` 按鈕寬度 fit-content，`×` 按鈕 28×28px
- [ ] 百分比欄輸入框右側有 `%` 後綴符號
- [ ] 地址字段分6個子欄位，底部有📍預覽行
- [ ] GIIN Code 4段分離輸入，自動 uppercase
- [ ] HRR Remarks 按鈕展開 inline panel，Others 勾選後展開 textarea
- [ ] 6種 Detail 彈窗各自正確開啟，22列表格渲染，Result Radio / Save 可操作
- [ ] Generate RSS 彈窗生成後插入示例行
- [ ] 審批意見展開 Modal 860px，內容可雙向同步
- [ ] 提交按鈕顏色隨審批結果選擇即時變化
- [ ] CCAI 表格列順序：Action / EN Name / CN Name / Related Co / Relation / Gender...
- [ ] Bank Supplement Attachment 兩個分區塊各自顏色 badge 正確
