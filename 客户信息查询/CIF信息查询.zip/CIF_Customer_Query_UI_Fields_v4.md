# CIF 對公客戶信息查詢 — UI 字段完整說明文檔

> **文檔版本：** `CIF_Customer_Query_UI_Fields_v4.md`
> **更新日期：** 2026-04-24
> **V4 補齊項目：**
> - §1.6 Anticipated Transaction 補齊：`Estimated the monthly payment amount`、`Estimated the amount of monthly payments`、`Estimated monthly payee amount`、`Estimate the amount of monthly payee` 四個 BIB 支付估計字段（CIF PRD 原文有，v3 遺漏）
> - §1.6 跨境交易字段名稱對齊 CIF PRD 原文完整名稱
> - §Header 操作按鈕欄補充 6 個功能按鈕完整說明
> - §附錄補充業務規則、枚舉值、Company Type 字典
> **參考來源：** CIF 客户信息查询.docx、BB_Account_Opening_Fields V1.9 MD、ZA BB RM 開戶說明書 v1.0

---

## 說明規範

| 符號 | 含義 |
|------|------|
| `[多值]` | 支持多條記錄，pill 標籤展示 |
| `[NS]` | 參與 Name Screening |
| `CHAR(n)` | 最大字符長度 |
| `NUM(m,n)` | 數值型，m 位整數 n 位小數 |

---

## 頁面概覽（10 個 Tab）

| Tab | 說明 |
|-----|------|
| Company Info | 公司基本信息（9 個子 Section） |
| Connected Party | 相關人士（Individual + Entity） |
| Asset Overview | 資產概覽（活期/定期/凍結/貸款/基金） |
| Card Information | 卡片信息 |
| Company Search | TU 查詢結果 |
| eKYC Records | 電子身份核實記錄 |
| Block Code | 狀態碼列表 |
| Authorization Arrangement | 簽名安排 + 變更歷史 |
| Attachment | 附件 |
| Audit Log | 風險評估審計記錄 |

---

## 客戶 Header Overview

> 公司英文/中文名稱大字置頂，字段分三行 3 欄等寬 grid 展示，不可折疊。

| 字段 | 類型 | 說明 |
|------|------|------|
| Company English Name | CHAR(60) | 公司英文名稱（大字顯示） |
| Company Chinese Name | CHAR(60) | 公司中文名稱 |

**第一行：身份信息（3 欄）**

| 字段 | 類型 | 說明 |
|------|------|------|
| Client No | CHAR(12) | 系統唯一客戶編號 |
| Client Status | CHAR(3) | 客戶狀態 badge（Active / Inactive 等） |
| ID Type | CHAR(3) | 證件類型（BR / CI） |
| ID Number | CHAR(30) | 證件號碼 |

**第二行：風險與審查（3 欄）**

| 字段 | 類型 | 說明 |
|------|------|------|
| Client Risk | CHAR(1) | 風險等級（H / M / L） badge |
| CDD Next Review Date | NUM(8) | 下次審查日期（臨近時橙色高亮） |
| CDD Last Review Date | NUM(8) | 上次審查日期 |

**第三行：客戶經理與開戶日期（3 欄）**

| 字段 | 類型 | 說明 |
|------|------|------|
| Account Officer | CHAR(10) | 客戶經理代碼 + 姓名 |
| Client Open Date | NUM(8) | 開戶日期 |
| Client Close Date | NUM(8) | 銷戶日期 |

**Header 下方操作欄（功能按鈕 — 綠底白字）**

| 按鈕 | 說明 |
|------|------|
| Create Trigger Event | 對該客戶創建觸發事件（Trigger Event）訂單，觸發客戶信息重新審核 |
| Create Periodic Review | 對該客戶創建年度定期審查（Periodic Review）訂單 |
| Create Periodic Review for EOB - Manual | 為 EOB（企業網銀）客戶手動創建定期審查訂單 |
| New DD Account | 為該客戶新開活期賬戶（DD Account） |
| AuditCL PDF | 生成並下載客戶審計合規清單（Audit Checklist）PDF 報告 |
| Company Info Update | 快速發起公司信息維護更新訂單 |

**Header 上方**

| 按鈕 | 說明 |
|------|------|
| ← 返回 | 返回客戶查詢列表 |

---

## Tab 1：Company Info

### 1.1 Company Base Information

| # | 字段 | 類型 | 說明 / 枚舉值 |
|---|------|------|---------------|
| 1 | Company Type | CHAR(2) | CO-LIMITED COMPANY(UNLISTED) / LC-LIMITED COMPANY(LISTED) / SP-SOLE PROPRIETORSHIP / PA-PARTNERSHIP / CS / EM / FD / FI / FU / GO / HC / JC / MS / NG / PC / PF / PT / SB / SO / TR / TU / VS / JP |
| 2 | Company Establish Date | NUM(8) | 公司成立日期，格式 YYYYMMDD |
| 3 | Country of Registration | CHAR(3) | 註冊國家（ISO 3166-1 alpha-3） |
| 4 | Listing Company | CHAR(1) | 是否上市公司。Y / N |
| 5 | High Tax Evasion Risk | CHAR(1) | 是否高逃稅風險。Y / N |
| 6 | Name(s) of Stock Exchange | CHAR(120) | 證券交易所名稱（Listing=Y 時顯示） |
| 7 | Bearer Shares Issued | CHAR(1) | 是否可發行不記名股票。Y / N |
| 8 | Bearer Shares Flag | CHAR(1) | 中介控股公司能否發行不記名股票。Y / N |
| 9 | Channel | CHAR(1) | 開戶渠道。O-E-Onboarding / W-Walk-in / A-Business Partner / I-Internal / B-RM Referral |
| 10 | Usage of Products | CHAR(1) | 高風險產品類型。1-Low Risk Only / 2-At Least One Medium Risk / 3-At Least One High Risk |
| 11 | On PEC | CHAR(1) | 是否政府標誌。Y / N |
| 12 | Number of layers of ownership structure | CHAR(2) | 股權結構層數。1-10 |
| 13 | Accounting Centre | NUM(11) | 客戶經理所屬核算單元 |
| 14 | Classify | CHAR(1) | 公司分類。S-SME / C-CORP / N-NBFI / Z-ZA GROUP |
| 15 | Internal Client Type | CHAR(2) | 內部客戶類型。PUBLIC SECTOR / OTHER |
| 16 | Business Nature | CHAR(5) | 業務性質。SMALL BUSINESS / SECURITIES FIRM / BANK / PUBLIC SECTOR / OTHER COMPANY / INSURANCE COMPANY / Other |
| 17 | Country Of Risk | CHAR(3) | 風險國家 |
| 18 | Country Of Origin | CHAR(3) | 總部所在國家 |
| 19 | Whether the board resolution document has been obtained | CHAR(1) | 是否取得董事會決議文件。Y / N |
| 20 | Trading Name (English) `[多值]` | CHAR(60) | 英文交易名稱，最多 10 個 |
| 21 | Trading Name (Chinese) `[多值]` | CHAR(60) | 中文交易名稱，最多 10 個 |

---

### 1.2 Contact Details

> 右上角「🕐 變更歷史」→ 地址變更歷史彈窗。

**地址信息（2 欄等寬 Grid）**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | Company Registered Address | CHAR(210) | 公司註冊地址 |
| 2 | Company Operation Address | CHAR(210) | 公司營業地址 |
| 3 | Company Mailing Address | CHAR(210) | 公司通訊地址 |
| 4 | Declaration (Secretary Address) | CHAR(1) | 1-Registered is secretarial firm / 2-Both are secretarial firm / 3-Registered is residential / 4-Both are residential |
| 5 | Reason | CHAR(500) | 地址為秘書公司/住宅地址的原因 |

**聯絡人信息**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 6 | Contact Person Last Name | CHAR(30) | 聯絡人姓氏 |
| 7 | Contact Person First Name | CHAR(30) | 聯絡人名字 |
| 8 | Contact Person Job Title | CHAR(3) | 01-董事 / 02-商人 / 03-東主 / 04-總經理 / 05-行政人員 / 06-高級行政人員 / 07-財務總監 / 08-秘書 / 09-其他 |
| 9 | Other Contact Person Job Title | CHAR(30) | Job Title=09 時顯示 |
| 10 | Contact Person Email Address | CHAR(34) | 聯絡人電郵 |
| 11 | Contact Person Telephone Number Area Code | CHAR(5) | 手機區號（852/86/84/66） |
| 12 | Contact Person Telephone Number | CHAR(18) | 聯絡人手機號碼 |
| 13 | Office Telephone Number | CHAR(18) | 辦事處電話 |
| 14 | Company Website | CHAR(120) | 公司網頁 |
| 15 | Group CIF Number | CHAR(12) | 集團客戶號碼 |
| 16 | Group CIF Name | CHAR(120) | 集團名稱 |

**地址變更歷史彈窗**

| 字段 | 說明 |
|------|------|
| 變更時間 | 變更具體時間 |
| 業務編號 | 關聯業務編號 |
| 業務類型 | Account Opening / Periodic Review / Trigger Event |
| 地址類型 | 注册地址 / 营业地址 / 通讯地址 |
| 變更後信息 | 變更後完整地址 |

---

### 1.3 Company Business Background

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | Office Location(s) | CHAR(3) | 辦公室地點（可多值） |
| 2 | Principal Place of Operations `[NS]` | CHAR(3) | 主要運營地 |
| 3 | Countries of Foreign Branch(es)/Subsidiary(ies)/Factory(ies) `[多值]` | CHAR(3) | 海外分支/子公司/工廠，最多 10 個 |
| 4 | Country of Key Counterparties `[多值]` | CHAR(3) | 主要交易對手國，最多 5 個 |
| 5 | Industry Category 1 | CHAR(6) | 行業大類（第一行業） |
| 6 | Key Products / Services 1 | CHAR(6) | 行業小類（第一行業） |
| 7 | Industry Category 2 | CHAR(6) | 行業大類（第二行業，選填） |
| 8 | Key Products / Services 2 | CHAR(6) | 行業小類（第二行業，選填） |
| 9 | Name of Regulatory Body | CHAR(120) | 監管機構名稱 |
| 10 | Regulatory Reference Number | CHAR(30) | 監管機構參考編號 |
| 11 | Country of Regulatory Body | CHAR(3) | 監管機構所在國家 |
| 12 | Country of Employee(s) / Number of Employee(s) `[多值]` | CHAR(3)+CHAR(5) | 雇員所在國及人數，最多 5 組 |
| 13 | Whether WEB3 Company | CHAR(1) | 是否 WEB3 公司。Y / N |
| 14 | Whether Greater China Company | CHAR(1) | 是否大中華區公司。Y / N |
| 15 | Financial Background | CHAR(5) | 1110-STATE-OWNED / 1120-COLLECTIVELY-OWNED / 1140-JOINT OPERATION / 1160-JOINT STOCK / 1170-PRIVATE-OWNED / 1175-INDIVIDUAL-OWNED / 1200-FOREIGN CAPITAL / 1330-HK/MACAU/TAIWAN CAPITAL / 9999-OTHERS |
| 16 | Is your Company a Holding Company | CHAR(1) | Y / N |
| 17 | Purpose for Account Opening `[多值]` | CHAR(3) | BO-BUSINESS OPERATIONS / IS-PAYMENT OF HIRE / IV-INVESTMENT / SF-SAVING/FIXED DEPOSIT / PR-PAYROLL / LO-LOAN / OT-OTHER（最多 5 個） |
| 18 | Others (Please Specify) | CHAR(200) | 其他開戶目的（Purpose=OT 時顯示） |
| 19 | Whether the annual turnover of the group exceeds HKD 1.5 billion | CHAR(1) | 集團年營業額是否超 15 億港元。Y / N |
| 20 | Non SME flag | CHAR(1) | 是否非 SME。Y / N |
| 21 | Referral Party | CHAR(60) | 開戶推薦人（Channel=B 時顯示） |

---

### 1.4 Financial Indicator of Latest Fiscal Year

**財務基本指標**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | Annual Business Turnover (HKD) | NUM(16,2) | 全年營業額（等值港幣） |
| 2 | Net Profit (HKD) | NUM(16,2) | 淨利潤 |
| 3 | Asset Size (HKD) | NUM(16,2) | 資產規模 |
| 4 | Others (Please Specify) | CHAR(200) | 其他財務補充說明 |

**Supplier（供應商）`[多值]` — 最多 10 條**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 5a | Countries Of Supplier | CHAR(3) | 供應商所在國家/地區 |
| 5b | Company Name Of Supplier | CHAR(120) | 供應商公司名稱 |
| 5c | Percentage of Total Purchase | CHAR(4) | 佔總採購百分比（0-100%） |

**Buyer（買方）`[多值]` — 最多 10 條**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 6a | Countries of Buyer | CHAR(3) | 買方所在國家/地區 |
| 6b | Company Name of Buyer | CHAR(120) | 買方公司名稱 |
| 6c | Percentage of Total Sales | CHAR(4) | 佔總銷售百分比（0-100%） |

**Countries of Which Assets Held（資產持有國）`[多值]` — 最多 10 條**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 7a | Countries of Which Assets Held | CHAR(3) | 資產所在國家/地區 |
| 7b | Percentage of Total Assets Held | CHAR(4) | 佔總資產百分比（0-100%） |

**SEQ 制裁合規問卷（Sanctions Exposure Questionnaire）— 4 條必填**

| 問題 | 字段名 | 類型 | 問題內容 |
|------|--------|------|----------|
| Q1 | Sanction_question1 | CHAR(1) | 公司目前或計劃在俄羅斯能源/石油天然氣/軍事或國防領域有任何業務？Y / N |
| Q2 | Sanction_question2 | CHAR(1) | 公司或關聯方是否有計劃在克里米亞/塞瓦斯托波爾地區開展業務？Y / N |
| Q3 | Sanction_question3 | CHAR(1) | 公司或關聯方是否為 UN/EU/UKHMT/HKMA/OFAC 或本地制裁法律目標？Y / N |
| Q4 | Sanction_question4 | CHAR(1) | 公司目前或計劃在制裁國家（Type 1+2）開展業務？Y / N |

**制裁國家業務補充（Q4=Y 時）`[多值]` — 最多 5 條**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 8a | Name of the Jurisdiction | CHAR(3) | 制裁國名稱（司法管轄權） |
| 8b | Purpose of business in the Jurisdiction | CHAR(120) | 於該國進行商業行為的目的 |

---

### 1.5 Source of Wealth / Fund

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | Initial Source of Wealth `[多值]` | CHAR(3) | 初始財富來源，最多 5 個。BI-BUSINESS INCOME / IF-INTRA-GROUP FINANCING / IP-INVESTMENT BY UBO/PARTNER / OT-OTHER / SA-SALE OF PROPERTY/ASSET |
| 2 | Other Initial Source of Wealth | CHAR(60) | 其他初始財富來源（SOW=OT 時必填） |
| 3 | Ongoing Source of Wealth `[多值]` | CHAR(3) | 持續財富來源，最多 5 個（同上枚舉） |
| 4 | Other Ongoing Source of Wealth | CHAR(60) | 其他持續財富來源 |
| 5 | Initial Source of Fund `[多值]` | CHAR(3) | 初始資金來源，最多 5 個（同上枚舉） |
| 6 | Other Initial Source of Fund | CHAR(60) | 其他初始資金來源 |
| 7 | Ongoing Source of Fund `[多值]` | CHAR(3) | 持續資金來源，最多 5 個（同上枚舉） |
| 8 | Other Ongoing Source of Fund | CHAR(60) | 其他持續資金來源 |

---

### 1.6 Anticipated Transaction & Purpose of Usage

**6.1 Cross Border Transaction（跨境交易）**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | Domestic / International Transaction | CHAR(1) | A-Domestic Payment / B-International Payment / C-Domestic and International Payment |
| 2 | Does the Company intent to make Cross Border Transaction | CHAR(1) | Y / N |
| 3 | Countries (to) of Cross Border Transaction `[多值]` | CHAR(3) | 匯出國家，最多 10 個 |
| 4 | Countries (from) of Cross Border Transaction `[多值]` | CHAR(3) | 匯入國家，最多 10 個 |
| 5 | Monthly Number of Cross Border Transaction (Inward) | CHAR(1) | 每月跨境入賬交易量。1至20宗 / 21至50宗 / 50宗以上 |
| 6 | Monthly Inward Amount of Cross Border Transaction - Currency | CHAR(3) | 每月跨境入賬貨幣（11 種貨幣列表） |
| 7 | Monthly Inward Amount of Cross Border Transaction - Amount | NUM(16,2) | 每月跨境入賬金額 |
| 8 | Monthly Number of Cross Border Transaction (Outward) | CHAR(1) | 每月跨境出賬交易量（同上枚舉） |
| 9 | Monthly Outward Amount of Cross Border Transaction - Currency | CHAR(3) | 每月跨境出賬貨幣 |
| 10 | Monthly Outward Amount of Cross Border Transaction - Amount | NUM(16,2) | 每月跨境出賬金額 |
| 11 | Purpose for Cross-Border Transaction `[多值]` | CHAR(3) | 跨境交易目的。Trading / Investment / Rental Payment/Collection / Payroll / Others |
| 12 | Other Purpose for Cross-Border Transaction | CHAR(200) | 其他跨境目的（Purpose=Others 時） |

**6.2 Regular Domestic Transaction（常規本地交易）**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 13 | Does the Company intend to make Regular Domestic Transaction | CHAR(1) | Y / N |
| 14 | Monthly Number of Regular Transaction (Inward) | CHAR(1) | 每月本地入賬交易量。1至20宗 / 21至50宗 / 50宗以上 |
| 15 | Monthly Inward Amount of Regular Transaction - Currency | CHAR(3) | 每月本地入賬貨幣 |
| 16 | Monthly Inward Amount of Regular Transaction - Amount | NUM(16,2) | 每月本地入賬金額 |
| 17 | Monthly Number of Regular Transaction (Outward) | CHAR(1) | 每月本地出賬交易量 |
| 18 | Monthly Outward Amount of Regular Transaction - Currency | CHAR(3) | 每月本地出賬貨幣 |
| 19 | Monthly Outward Amount of Regular Transaction - Amount | NUM(16,2) | 每月本地出賬金額 |
| 20 | Purpose for Regular Transaction `[多值]` | CHAR(3) | 本地交易目的（同跨境枚舉） |
| 21 | Other Purpose for Regular Transaction | CHAR(200) | 其他本地目的 |
| 22 | Does the Company intend to hold balances in the account with infrequent activity | CHAR(1) | Y / N |
| 23 | Please indicate the amount and rationale | CHAR(120) | 金額及理由（Hold Balances=Y 時必填） |

**6.3 BIB 支付估計（Estimated Payment/Payee）**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 24 | Estimated the monthly payment amount | ENUM | 估計每月付款金額。0至60,000港元 / 60,001至600,000港元 / 600,001至3,000,000港元 / 3,000,001至6,000,000港元 / 6,000,000港元以上 |
| 25 | Estimated the amount of monthly payments | ENUM | 估計每月付款數量。1至20宗 / 21至50宗 / 50宗以上 |
| 26 | Estimated monthly payee amount | ENUM | 估計每月收款金額（枚舉同 #24） |
| 27 | Estimate the amount of monthly payee | ENUM | 估計每月收款數量（枚舉同 #25） |

---

### 1.7 FATCA / CRS

**公司層面 FATCA**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | FATCA Documentation | CHAR(2) | 01-Form W-8BEN-E / 02-Form W-9 / 03-Self-certification / 04-Others / 05-Form W-8ECI / 06-Form W-8EXP / 07-Form W-8BEN / 08-Form W-8IMY and Withholding Statement / 09-Substitute Form W-8BEN-E |
| 2 | Others – Please specify | CHAR(2) | 其他 FATCA 表格（Documentation=04 時） |
| 3 | FATCA Classification | CHAR(2) | FATCA 身份類型（39 個枚舉，01~39） |
| 4 | Non-consenting U.S. account Sub-type | CHAR(2) | 01-USP / 02-Passive NFFE / 03-Dormant / 04-With US indicia / 05-Without US indicia（Classification=37 時必填） |
| 5 | Disregarded entity | ENUM | 非獨立實體公司。Y / N |
| 6 | Sign Date of FATCA Documentation | NUM(8) | 簽署 FATCA 表格日期 |
| 7 | FATCA Due Diligence Status | CHAR(2) | 01-Completed Normal / 02-Completed Enhanced / 03-Incomplete / 04-N/A |
| 8 | FATCA pre-existing account | CHAR(1) | 是否 FATCA 既有賬戶。Y / N |

**公司層面 CRS**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 9 | CRS Entity Classification | CHAR(2) | 01-FINANCIAL INSTITUTION-1 至 08-PASSIVE NON-FINANCIAL ENTITY(PNFE)-2 |
| 10 | Sign Date of CRS Documentation | NUM(8) | 簽署 CRS 表格日期 |
| 11 | CRS self-certification valid | CHAR(1) | CRS 自我聲明是否有效。Y / N |
| 12 | CRS pre-existing account | CHAR(1) | 是否 CRS 既有賬戶。Y / N |
| 13 | Tax Residency `[多值]` | CHAR(3) | 稅務國家/地區，最多 10 個 |
| 14 | Tax identifying number (TIN) `[多值]` | CHAR(22) | 稅務號碼，最多 10 個 |
| 15 | Reason for No TIN `[多值]` | CHAR(1) | Reason A-所在地不發 TIN / Reason B-無法取得 / Reason C-TIN 不適用 |
| 16 | GIIN Code | CHAR(16) | 全球中介機構識別號碼（特定 Classification 時必填） |
| 17 | GIIN Status | CHAR(1) | ACTIVE / INACTIVE / REVOKED / EXPIRED |

---

### 1.8 Company Change

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | Have there been Material Changes to your Business in the last 5 years? | CHAR(1) | Y / N |
| 2 | Company Name Changed | CHAR(1) | Y / N |
| 3 | Old Company Name(s) `[多值]` | CHAR(90) | 舊公司名稱（中英文，最多 10 個），含變更日期 |
| 4 | Products and Services Changed | CHAR(1) | Y / N |
| 5 | Old Industry Category / Key Products / Services `[多值]` | CHAR(6) | 舊行業大類/小類，最多 10 個，含日期區間 |
| 6 | Ownership Structure Changed | CHAR(1) | Y / N |
| 7 | Ownership Structure Change Period（Start + End） | NUM(8)+NUM(8) | 股權結構變更日期區間 |
| 8 | Reasons for changing Company Ownership Structure | CHAR(500) | 股權結構變更原因 |
| 9 | Beneficial Owners Changed | CHAR(1) | Y / N |
| 10 | Beneficial Owners Change Period（Start + End） | NUM(8)+NUM(8) | 受益所有人變更日期區間 |
| 11 | Reasons for changing Beneficial Owners | CHAR(500) | 受益所有人變更原因 |

---

### 1.9 Company Search — Company Secretary Information

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | ID Type | CHAR(3) | BR / CI / LEI / OTHERS |
| 2 | ID Number | CHAR(30) | 秘書公司證書號碼 |
| 3 | Company English Name `[NS]` | CHAR(60) | 秘書公司英文名稱（修改後強制 CRA Rerun） |
| 4 | Company Chinese Name | CHAR(60) | 秘書公司中文名稱 |
| 5 | Company Secretary Address | CHAR(210) | 秘書公司地址 |

---

## Tab 2：Connected Party

### 2.1 Individuals

> 每個 Individual 塊右上角有「🕐 變更歷史」按鈕。

**基本身份信息**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | ID Type | CHAR(3) | ID-HK Identity Card / PP-Passport / CD-Chinese Resident Identity Card / PT-Others |
| 2 | Other ID Type | CHAR(60) | 其他證件類型（ID Type=PT 時） |
| 3 | ID Number | CHAR(30) | 證件號碼 |
| 4 | First Name `[NS]` | CHAR(30) | 英文名 |
| 5 | Last Name `[NS]` | CHAR(30) | 英文姓氏 |
| 6 | Chinese Name `[NS]` | CHAR(60) | 中文姓名 |
| 7 | Capacity of Connected Party | CHAR(3) | 085-Beneficial Owner / 034-Director / 065-Partner / 114-Sole Proprietor / 084-Beneficiary / 069-Shareholder≥25% / 103-Senior Officer / 005-Authorised Representative / 019-Internet Banking Rep / 045-Guarantor / 060-Trustee / 104-Settlor / 105-Protector / 117-Project S Contact / 118-Controlling Person / 119-Contact Person / 120-BIB Maker / 121-BIB Administrator |
| 8 | Controlling Person Type | CHAR(6) | Capacity=118 時必填。CRS801-LEGAL PERSON-OWNERSHIP / CRS802-OTHER MEANS / CRS803-SENIOR MANAGING OFFICIAL / CRS804-TRUST-SETTLOR / CRS805-TRUSTEE / CRS806-PROTECTOR / CRS807-BENEFICIARY / CRS808-OTHER / CRS809~CRS813 |
| 9 | Sign Date of CRS Documentation (for Controlling Person) | NUM(8) | 簽署 CRS 表格日期 |
| 10 | Tax residency `[多值]` | CHAR(3) | 稅務國家，最多 10 個 |
| 11 | Tax identification number (TIN) `[多值]` | CHAR(30) | 稅務號碼，最多 10 個 |
| 12 | Reason for no TIN `[多值]` | CHAR(200) | 無稅務號碼原因（A/B/C） |
| 13 | Ownership | CHAR(3) | 股份佔比 |
| 14 | Job Title | CHAR(30) | 職銜 |
| 15 | Permanent HKID | CHAR(1) | 是否永久性居民身份證。Y / N |
| 16 | ID Issue Date | NUM(8) | 身份証明文件簽發日期 |
| 17 | Gender | CHAR(3) | M-Male / F-Female |
| 18 | Date of Birth `[NS]` | NUM(8) | 出生日期 |
| 19 | Place of Birth `[NS]` | CHAR(3) | 出生地（國家） |
| 20 | Nationality `[NS][多值]` | CHAR(3) | 國籍，最多 5 個 |
| 21 | Email Address | CHAR(34) | 電郵地址 |
| 22 | Telephone Number Area Code | CHAR(5) | 電話區號 |
| 23 | Telephone Number | CHAR(18) | 電話號碼 |
| 24 | Residential Address `[NS]` | CHAR(210) | 居住地址 |
| 25 | Beneficial Owner Source of Wealth `[多值]` | CHAR(3) | 受益所有人財富來源（僅 Beneficial Owner），最多 5 個。BI / IF / IP / OT / SA |
| 26 | Others (Please Specify) | CHAR(200) | 其他財富來源（SOW=OT 時） |
| 27 | Country(ies) in which Beneficial Owner attained his/her Initial Source of Wealth `[多值]` | CHAR(3) | 初始財富來源國（僅 BO），最多 5 個 |
| 28 | Country(ies) in which Beneficial Owner attained his/her Ongoing Source of Wealth `[多值]` | CHAR(3) | 持續財富來源國（僅 BO），最多 5 個 |
| 29 | Related Client On PEP | CHAR(1) | PEP 標誌。Hong Kong PEP / Non Hong Kong PEP / International Organization PEP / No |
| 30 | Signature Specimen | 附件 | 簽名式樣（查看簽名按鈕） |

**FATCA（個人）**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| F1 | US Tax ID (FATCA TIN) | CHAR(30) | 美國稅務識別號碼（US Person 適用） |
| F2 | Substantial US owner flag | CHAR(1) | 是否為實體的重大美國股東。Y / N |

**CRS（個人）**

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| C1 | Entity controlling person flag | CHAR(1) | 是否為實體控制人（CRS）。Y / N |
| C2 | CRS Tax Residency `[多值]` | CHAR(3) | CRS 稅務居留國，最多 4 個 |
| C3 | CRS TIN `[多值]` | CHAR(30) | CRS 稅務識別號碼 |
| C4 | CRS Reason for No TIN `[多值]` | CHAR(200) | 無 CRS TIN 原因 |
| C5 | Type of Controlling Person | CHAR(2) | 01-Controlling ownership interest / 02-Control through other means / 03-Senior managing official / 04-Settlor / 05-Trustee / 06-Protector/Enforcer / 07-Beneficiary / 08-Other / 09-Equivalent to Settlor / 10-Equivalent to Trustee / 11-Equivalent to Protector / 12-Equivalent to Beneficiary / 13-Other equivalent |

**自然人變更歷史彈窗**

| 字段 | 說明 |
|------|------|
| 變更時間 | 具體時間 |
| 業務編號 | 關聯業務編號 |
| 業務類型 | Account Opening / Periodic Review / Trigger Event |
| 變更字段名稱 | 具體變更的字段 |
| 變更後信息 | 變更後的完整信息 |

---

### 2.2 Entities

> 每個 Entity 塊右上角有「🕐 變更歷史」按鈕。

| # | 字段 | 類型 | 說明 |
|---|------|------|------|
| 1 | ID Type | CHAR(3) | CI / BR / LEI / OTHERS |
| 2 | Other ID Type | CHAR(60) | 其他證件類型 |
| 3 | ID Number | CHAR(30) | 證件號碼 |
| 4 | Registered Full Name in English `[NS]` | CHAR(60) | 公司英文名稱 |
| 5 | Registered Full Name in Chinese | CHAR(60) | 公司中文名稱 |
| 6 | Entity Type of Connected Entity | CHAR(2) | 同 Company Type 枚舉 |
| 7 | Capacity of Connected Entity | CHAR(3) | 同 Individual 枚舉 |
| 8 | Ownership | CHAR(3) | 股份佔比 |
| 9 | Listing on Stock Exchange | CHAR(1) | Y / N |
| 10 | Name(s) of Stock Exchange | CHAR(120) | 證券交易所名稱 |
| 11 | Registered Office Address `[NS]` | CHAR(210) | 公司註冊地址（Senior Officer/Director/Authorised Rep 時顯示） |
| 12 | Principal Business Address `[NS]` | CHAR(210) | 主要營業地址（Senior Officer 時顯示） |

**公司變更歷史彈窗**（字段同自然人變更歷史彈窗）

---

## Tab 3：Asset Overview

### 3.1 資產概覽統計

| 字段 | 說明 |
|------|------|
| Currency (HKD equivalent) | 貨幣選擇（HKD / USD / CNY） |
| Total amount (HKD equivalent) | 所有帳戶等值港幣總額 |

> 環形圖展示 DD（活期）/ TD（定期）資產佔比。

### 3.2 DD 活期帳戶

| # | 字段 | 說明 |
|---|------|------|
| 1 | Application Type | DD - 活期 |
| 2 | Account/Contract No. | 活期賬號（點擊查看 Balance Details） |
| 3 | Account Type | House Account / Client Account / SFGS Account / Payroll account / Solar House Account / Solar Client Account / Suspense Account / VPA Account |
| 4 | Account Name | 賬戶名稱 |
| 5 | Currency (HKD equiv.) | 貨幣 |
| 6 | Current Book Balance (HKD equiv.) | 賬面餘額 |
| 7 | Open Date | 開戶日期 |
| 8 | Close Date | 銷戶日期 |
| 9 | Account Status | A-正常 / I-不活躍 / D-不動戶 / C-已銷戶 |
| 10 | Last Financial Transaction Date | 最後金融交易日期 |
| 11 | Last Action | Balance Details 按鈕 |

**Balance Details 彈窗**

| 字段 | 說明 |
|------|------|
| Currency | 貨幣 |
| Current Book Balance | 賬面餘額 |
| Available Balance | 可用餘額 |

### 3.3 TD 定期帳戶

| # | 字段 | 說明 |
|---|------|------|
| 1 | Application Type | TD - 定期 |
| 2 | Account/Contract No. | 定期賬號 |
| 3 | Serial No. | 轉期序號 |
| 4 | Currency | 貨幣 |
| 5 | Status | ACTIVE / INACTIVE / DORMANT / CLOSED |
| 6 | Product Code | 產品代碼（如 TDC00001） |
| 7 | Principal | 本金 |
| 8 | Tenor | 存期 |
| 9 | Contract Rate | 合約利率 |
| 10 | Interest Amount | 利息金額 |
| 11 | Value Date | 起息日 |
| 12 | Maturity Date | 到期日 |
| 13 | Maturity Instruction | 0-Pending / 1-PRIN ROLLOVER INT TO ACCOUNT / 2-Principal Plus Interest Rollover / 5-Principal And Interest To DD Account |

### 3.4 Funds Freezing

| 字段 | 說明 |
|------|------|
| Freeze Type | 凍結類型 |
| Freeze Amount | 凍結金額 |
| Freeze Date | 凍結日期 |
| Freeze Reason | 凍結原因 |
| Freeze Status | 凍結中 / 已解凍 |

### 3.5 Loan Information

| 字段 | 說明 |
|------|------|
| Loan Type | PL/MT/CC 等 |
| Loan Account | 貸款賬號 |
| Loan Amount | 貸款金額 |
| Loan Effective Date | 生效日期 |
| Loan Maturity Date | 到期日期 |

### 3.6 Fund Information

| 字段 | 說明 |
|------|------|
| Fund Type | MF/ETF/BD 等 |
| Fund Account | 基金賬號 |
| Fund Name | 基金名稱 |
| Fund Amount | 基金金額 |
| Fund Status | Active / Closed |

---

## Tab 4：Card Information

| # | 字段 | 說明 |
|---|------|------|
| 1 | Card Number | 卡號 |
| 2 | Account Number | 關聯賬號 |
| 3 | Open Date | 開卡日期 |
| 4 | Activation Date | 激活日期 |
| 5 | Activation Status | Activated / Not Activated |
| 6 | Close Date | 銷卡日期 |

---

## Tab 5：Company Search

### 5.1 TU Entity Details

| 字段 | 說明 |
|------|------|
| Company type | TU 返回公司類型 |
| Company status | 公司狀態 |
| Company name | 公司名稱 |
| Incorporation date | 成立日期 |
| Company registered address | 公司註冊地址 |

### 5.2 Connected Party

| # | 字段 | 說明 |
|---|------|------|
| 1 | Role | 角色 |
| 2 | ID Type | 證件類型 |
| 3 | Other ID Type | 其他證件類型 |
| 4 | ID Number | 證件號碼 |
| 5 | First Name | 英文名 |
| 6 | Last Name | 英文姓氏 |
| 7 | Percentage of share of shareholders | 股份佔比 |

### 5.3 Related Documents

| # | 字段 | 說明 |
|---|------|------|
| 1 | Document Type | Business registration certificate / Certificate of incorporate / NAR1 / M&A / Form1(a) / Form1(c) / Other |
| 2 | File Name | 文件名稱 |
| 3 | Action | 查看按鈕 |

---

## Tab 6：eKYC Records

| # | 字段 | 說明 |
|---|------|------|
| 1 | Authentication Time | 認證時間 |
| 2 | ID Card Video | 身份証視頻 |
| 3 | ID Card Image | 身份証圖片（正面/背面） |
| 4 | Selfie | 自拍圖片 |
| 5 | OCR Information | OCR 識別信息（姓名/證件號/出生日） |
| 6 | Authentication result | Pass / Attention / Reject |
| 7 | Overall Score | 綜合評分 |
| 8 | Detailed Rating | 人臉匹配 / 文件質量 / 活體檢測 |
| 9 | Device Information | 設備型號及系統版本 |
| 10 | IP Address | 認證時 IP 地址 |
| 11 | GPS Information | GPS 地理位置 |

---

## Tab 7：Block Code

| # | 字段 | 說明 |
|---|------|------|
| 1 | Transaction Seq | 交易流水號 |
| 2 | Rule ID Number | 規則 ID |
| 3 | Client Number | 客戶號 |
| 4 | Account Number | 賬號 |
| 5 | Vertical | 1-Retail / 2-Business |
| 6 | Channel | 1-CAAS / 2-ARK / 3-EOB |
| 7 | Block Code | 狀態碼 |
| 8 | Action | 1-Add（綠） / 2-Remove（紅） |
| 9 | Reason | 設置原因 |
| 10 | Setting Mode | 1-系統 / 2-人工 |
| 11 | Checker | 審核員 |

---

## Tab 8：Authorization Arrangement

### 8.1 Signing Arrangement

| # | 字段 | 說明 |
|---|------|------|
| 1 | CI Number | 客戶號 CHAR(12) |
| 2 | Company English Name | 公司英文名稱 CHAR(120) |
| 3 | Signing Instruction | Only one to sign / Any one to sign / Any two to sign / Any three to sign / Any four to sign / Any five to sign / Any six to sign |
| 4 | ID Type | 授權代表證件類型 |
| 5 | ID Number | 授權代表證件號碼 |
| 6 | Authorised Representative English Name | 授權代表英文名 CHAR(120) |
| 7 | Signature Specimen | 查看簽名按鈕 |

### 8.2 Modification History

| # | 字段 | 說明 |
|---|------|------|
| 1 | Modification Time | 維護時間 |
| 2 | Case Number | 業務編號 |
| 3 | Case Type | Account Opening / Trigger Event / Periodic Review |
| 4 | Update Type | Add / Update / Delete |
| 5 | ID Type | 授權代表證件類型 |
| 6 | ID Number | 授權代表證件號碼 |
| 7 | Authorised Representative English Name | 授權代表英文名 |

---

## Tab 9：Attachment

| # | 字段 | 說明 |
|---|------|------|
| 1 | No. | 序號 |
| 2 | Document Name | 文件名稱 |
| 3 | Uploader | 上傳人 |
| 4 | Upload time | 上傳時間 |
| 5 | Download | 下載按鈕 |

---

## Tab 10：Audit Log

| # | 字段 | 說明 |
|---|------|------|
| 1 | No. | 序號 |
| 2 | Submission Time | 提交時間 |
| 3 | Case Number | 訂單號 |
| 4 | Case Type | Account Opening / Periodic Review / Trigger Event |
| 5 | Risk Rate | L-Low / M-Medium / H-High |
| 6 | Total Score | 風險評估分數 |
| 7 | Link | Detail 跳轉按鈕 |

---

## 附錄 A：Company Type 數據字典

| 代碼 | 說明 |
|------|------|
| CO | LIMITED COMPANY (UNLISTED) |
| LC | LIMITED COMPANY (LISTED) |
| CS | COOPERATIVE SOC |
| EM | EMBASSY |
| FD | FOUNDATION |
| FI | FINANCIAL INSTITUTION |
| FU | FUND |
| GO | GOVERNMENT DEPARTMENT |
| HC | HOLDING COMPANY |
| JC | JOINT CORP |
| MS | MONEY SERVICE BUSINESS |
| NG | NATIONAL OR LOCAL BODY GOVERNMENT |
| PC | PRIVATE INVESTMENT COMPANY |
| PF | PRIVATE INVESTMENT FUND |
| PT | PRIVATE HOLDING TRUST |
| SB | STATUTORY BODY |
| SO | SOCIETY |
| SP | SOLE PROPRIETORSHIP |
| TR | TRUST |
| TU | TRADE UNION |
| VS | VOLUNTARY SECTOR |
| JP | JOINT PERSON |
| PA | PARTNERSHIP |

---

## 附錄 B：通用 UI 規範

**Badge 顏色**

| 顏色 | 適用場景 |
|------|---------|
| 綠色 | Active / Pass / Low Risk / Add |
| 黃色（橙） | Medium Risk / Attention / Pending |
| 紅色 | High Risk / Reject / Remove / Frozen |
| 藍色 | Account Opening / ID 標籤 |
| 紫色 | Periodic Review |
| 灰色 | N-No / Inactive / Closed |

**國家 Pill**

| 顏色 | 說明 |
|------|------|
| 黃底 `#ffe58f` | 制裁/高風險國家 |
| 藍底 `#e6f4ff` | 正常/香港本地國家 |

**交互說明**

- Section 右上角 **▼** 可折疊/展開
- `[多值]` 字段以 pill 標籤展示
- 地址字段展示於灰底圓角 `.addr-box`
- 三個變更歷史彈窗（地址/Individual/Entity）點擊遮罩或 ✕ 關閉

---

## 附錄 C：關鍵業務規則

| 規則 | 說明 |
|------|------|
| BIB SMS 區號限制 | 僅支持 852（香港）、86（大陸）、84（越南）、66（泰國）區號 |
| Greater China 判定 | 任一 UBO 為中國人 / 供應商中國占比>50% / 買方中國占比>50% |
| 高風險產品 | VAS Account / Solar House Account / Solar Client Account / Commercial Card (VPA) |
| 秘書公司英文名稱變更 | 強制觸發 CRA Rerun |
| CRS Controlling Person | Capacity=118-Controlling Person 時，Type 為必填 |
| Name Screening 觸發 | `[NS]` 標記字段內容變更時自動觸發掃描 |
| BO Source of Wealth | 僅適用於 Capacity=Beneficial Owner 的相關人士 |
| SEQ 制裁問卷 | Q1/Q2/Q3 任一回答 Y → 開戶申請拒絕；Q4=Y 且在相關行業 → 拒絕 |
